const express = require('express');
const app = express();
const http = require('http');
const server = http.createServer(app);
const { Server } = require("socket.io");
const io = new Server(server); //import socket.io 

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
  });

    //on() is an even handler that lets you listen to the event that will be fired, 'connnection' is the even here
    //the chat-message event will be fired using the emite() method
  io.on('connection', (socket) => {
    socket.on('chat message', msg => {
      io.emit('chat message', msg); //this will send the message to everyone that is connected to the server except the person that sent the message
    });
  });
  

server.listen(3000);
